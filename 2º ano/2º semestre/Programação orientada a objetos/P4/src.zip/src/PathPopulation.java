import java.util.ArrayList;

/** A classe PathPopulation como indica é uma população de trajetorias ou seja armazena-as e tem os seus devidos metodos
    @Author AfonsoRio
    @version 1.0 19/03/2023
    @inv
 */
public class PathPopulation {
    private ArrayList<Path> trajectoryList = new ArrayList<>();

    /**Contrutor que armazena as trajetorias na lista "trajectoryList"
     * @param trajectoryList lista de trajetorias
     */
    public PathPopulation(ArrayList<Path> trajectoryList){
        this.trajectoryList = trajectoryList;
    }

    /**Contrutor vazio
     */
    public PathPopulation(){}


    /**Adiciona uma trajetoria á população
     * @param a
     */
    public void add(Path a){
        trajectoryList.add(a);
    }

    /**Imprime as trajetorias armazenadas na população
     */
    public void printPaths(){
        for(int i = 0; i < trajectoryList.size(); i++)
            System.out.println(trajectoryList.get(i));
    }
}
