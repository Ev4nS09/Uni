/*Formula usada no metodo checkIntersecao
 * Por Exemplo temos um segmento s1 e s2 que queremos saber se intersetao
 * P1 = s1.getA()
 * P2 = s1.getB()
 * P3 = s2.getA()
 * P4 = s2.getB()
 *  (P4.getX() - P3.getX())*(P1.getY() - P3.getY()) - (P4.getY() - P3.getY())*(P1.getX() - P3.getX())
 * --------------------------------------------------------------------------------------------------- = U
 * ((P4.getY() - P3.getY())*(P2.getX() - P1.getX()) - (P4.getX() - P3.getX())*(P2.getY() - P1.getY()))
 * 
 * (P2.getX() - P1.getX())*(P1.getY() - P3.getY()) - (P2.getY() - P1.getY())*(P1.getX() - P3.getX())
 * ---------------------------------------------------------------------------------------------------- = V
 * ((P4.getY() - P3.getY())*(P2.getX() - P1.getX()) - (P4.getX() - P3.getX())*(P2.getY() - P1.getY()))
 * 
 * Para ocorrer uma interseçao entre dois segmentos o valor U e V têm q pertencer ao intervalo [0, 1].
 * Mas se as linhas forem coicidentes entao u = 0 v = 0 e denominador = 0 vai existir interseção
 */

/** A classe segmento vai contruir um segmento a partir de dois pontos dados.
    @AfonsoRio
    @version 1.0 21/02/2023
    @inv Dois pontos não podem ser iguais
 */

class Segmento{
    private Ponto a, b;

    /** O construtor vai armazenar dois pontos diferentes
        @param a Ponto diferente de b
        @param b Ponto diferente de a
 */

    public Segmento(Ponto a, Ponto b){
        checkSegmento(a, b);
        if(b.getX() > a.getX()){
            this.a = a;
            this.b = b;
        }
        else if(b.getY() > a.getY()){
            this.a = a;
            this.b = b;
        }
        else{
            this.a = b;
            this.b = a;
        }
    }

    public void checkSegmento(Ponto a, Ponto b){
        if(a.equals(b)){
            System.out.println("Segmento:vi");
            System.exit(0);
        }
    }

    /** O metodo getA ou getB vai retornar os Pontos armazenados de um segmento
    @return retorna um a ou b
    */

    public Ponto getA(){return a;}

    public Ponto getB(){return b;}

    /** O metodo checkIntersecao vai verificar se existe interseçao entre um segmento recetor this e o seu argumento segmentoDeReta, e podemos escolher mostras o status da funçao com
     * um boolean
    @param segmentoDeReta um segmento
    @param displaySatatus boolean
    @return retorna um boolean
    @see http://www.youtube.com/watch?v=EFxSbhW-znc
    @see http://www.dpi.inpe.br/gilberto/livro/bdados/cap2.pdf
    */

    public boolean checkIntersecao(Segmento segmentoDeReta){
        boolean result = false;
        Ponto P1 = this.a;
        Ponto P2 = this.b;
        Ponto P3 = segmentoDeReta.getA();
        Ponto P4 = segmentoDeReta.getB();
        double denominador = ((P4.getY() - P3.getY())*(P2.getX() - P1.getX()) - (P4.getX() - P3.getX())*(P2.getY() - P1.getY()));
        double numeradorU = (P4.getX() - P3.getX())*(P1.getY() - P3.getY()) - (P4.getY() - P3.getY())*(P1.getX() - P3.getX());
        double numeradorV = (P2.getX() - P1.getX())*(P1.getY() - P3.getY()) - (P2.getY() - P1.getY())*(P1.getX() - P3.getX());
        if(denominador == 0 && numeradorU == 0 && numeradorV == 0){   //Os segmentos sao coincidentes
            if(P1.getX() > P3.getX() || P1.getY() > P3.getY()) return checkCoincidente(P3, P4, P1, P2);
            else return checkCoincidente(P1, P2, P3, P4);
        }
        else if(denominador == 0){
            result = false;
        }
        else if((numeradorU/denominador >= 0 && numeradorU/denominador <= 1) && (numeradorV/denominador >= 0 && numeradorV/denominador <= 1)){
            result = true;
        }
        return result;
    }


    public boolean checkIntersecao(Segmento segmentoDeReta, boolean displayStatus){
        if(!displayStatus) return checkIntersecao(segmentoDeReta);

        if(checkIntersecao(segmentoDeReta)){
            System.out.println("Fail");
            System.exit(0);
        }
        return false;
    }

    public boolean checkCoincidente(Ponto P1, Ponto P2, Ponto P3, Ponto P4){
        boolean result = false;
        if(P1.getX() == P2.getX() && P2.getX() == P3.getX() && P3.getX() == P4.getX()){
            if(P3.getY() <= P1.getY() && P4.getY() >= P1.getY() || P3.getY() <= P2.getY() && P4.getY() >= P2.getY()){
                result = true;
            }
        }
        else if(P1.getY() == P2.getY() && P2.getY() == P3.getY() && P3.getY() == P4.getY()){
            if(P3.getX() <= P1.getX() && P4.getX() >= P1.getX() || P3.getX() <= P2.getX() && P4.getX() >= P2.getX()){
                result = true;
            }
        }
        return result;
    }

    public boolean equals(Segmento s){ 
        if((this.a.equals(s.getA()) && this.b.equals(s.getB())) || (this.a.equals(s.getB()) && this.b.equals(s.getA()))) return true;
        else return false;
    }
}